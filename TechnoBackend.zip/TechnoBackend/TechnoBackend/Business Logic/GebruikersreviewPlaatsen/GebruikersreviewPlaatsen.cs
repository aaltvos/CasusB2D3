﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TechnoBackend.Business_Logic.GebruikersreviewPlaatsen
{ 
    public class GebruikersreviewPlaatsen
    {
        public class GetReview
        {
            string review = "this is a dumy review thats really pretty short and not really useful";

        }
    }
}